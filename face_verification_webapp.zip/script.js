
async function captureAndVerify() {
  const status = document.getElementById("status");
  const video = document.getElementById("video");

  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
  const imageData = canvas.toDataURL("image/jpeg");

  status.innerText = "Verifying...";

  try {
    const response = await fetch('https://script.google.com/macros/s/AKfycbyshd0220WUL0-K1xUbp9Xr3yoXn3y93gvPoItzbm8GI1FIejsRpG-LaCocRDXqD_Ma7w/exec', {
      method: 'POST',
      body: JSON.stringify({ image: imageData }),
      headers: { "Content-Type": "application/json" }
    });

    const result = await response.json();
    if (result.success) {
      status.innerText = "✅ Face Verified. You may proceed.";
    } else {
      status.innerText = "❌ Face not recognized. Try again.";
    }
  } catch (e) {
    status.innerText = "❌ Error verifying face.";
    console.error(e);
  }
}

// Get camera stream
navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
  document.getElementById("video").srcObject = stream;
}).catch(error => {
  alert("Camera access denied.");
});
